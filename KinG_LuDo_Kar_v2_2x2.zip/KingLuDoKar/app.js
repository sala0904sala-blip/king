let coins=10000,wins=0,games=0,refs=0;
const diceEl=document.getElementById('dice');
function roll(){let n=Math.floor(Math.random()*6)+1;diceEl.textContent=n;document.getElementById('status').textContent='🎲 Кубик: '+n+' — жүріс кезегі.'}
function send(){const i=document.getElementById('msg');if(!i.value.trim())return;const d=document.createElement('div');d.textContent='👤 Сен: '+i.value;document.getElementById('chat').appendChild(d);i.value='';}
const uid='player'+Math.random().toString(36).slice(2,9);
document.getElementById('ref').value='https://t.me/KinGLuDoKar_bot?start=ref_'+uid;
function copyRef(){navigator.clipboard?.writeText(document.getElementById('ref').value);alert('Сілтеме көшірілді!')}
document.getElementById('coins').textContent=coins;
document.getElementById('wins').textContent=wins;
document.getElementById('games').textContent=games;
document.getElementById('refs').textContent=refs;