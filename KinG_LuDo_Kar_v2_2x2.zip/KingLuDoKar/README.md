# KinG LuDo Kar

Бұл — Telegram Mini App үшін бастапқы Ludo прототипі.

Қосылған прототип:
- 2–4 ойыншы интерфейсі
- 4 түс
- кубик
- профиль/статистика
- virtual coin: 10 000 бастапқы баланс
- referral интерфейсі
- 10 referral -> 10 000 virtual coin логикасына арналған UI
- турнир/рейтинг экраны
- мәтіндік чат интерфейсі

Ескерту: бұл нұсқада coin — тек virtual coin. Real-money betting/withdrawal жоқ.

Келесі техникалық кезең:
1. Telegram Mini App backend
2. нақты multiplayer WebSocket
3. толық Ludo ережелері
4. Telegram user ID арқылы профиль
5. серверлік coin/referral сақтау
6. турнирлер және рейтинг
7. WebRTC voice chat
